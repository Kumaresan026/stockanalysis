from setuptools import setup, find_packages

setup(
    name="stock-event-engine",
    version="0.1.0",
    author="Kumaresan",
    author_email="kumaresan2126@gmail.com",
    description="Event-driven stock analytics and alert engine",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "boto3",
        "pandas"
    ],
    python_requires=">=3.8",
)