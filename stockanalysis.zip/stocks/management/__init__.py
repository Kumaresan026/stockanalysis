# Required for Django management package
